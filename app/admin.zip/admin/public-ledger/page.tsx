"use client"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Building,
  FileText,
  Home,
  LogOut,
  Search,
  Settings,
  Store,
  Truck,
  Database,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Clock,
  ShieldCheck,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { auth } from "@/lib/firebase"
import { signOut, getAuth, onAuthStateChanged } from "firebase/auth"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

// Sample data for the public ledger
const ledgerTransactions = [
  {
    id: "TX-001",
    hash: "0x8f7e6d5c4b3a2918d7e6d5c4b3a2918d7e6d5c4",
    timestamp: "2023-05-15T10:30:45",
    commodity: "Wheat",
    quantity: "200 tons",
    broughtFrom: "Punjab Farms Collective",
    sourceLocation: "Amritsar, Punjab",
    storedAt: "Delhi Central Warehouse",
    storageLocation: "Central Delhi",
    soldTo: "Delhi Central Ration Shop",
    destinationLocation: "Central Delhi",
    price: "₹30,000/ton",
    totalValue: "₹60,00,000",
    status: "Completed",
    previousHash: "0x7d6e5c4b3a2918d7e6d5c4b3a2918d7e6d5c4b3",
    blockNumber: 1045678,
    verified: true,
  },
  {
    id: "TX-002",
    hash: "0x7e6d5c4b3a291807e6d5c4b3a291807e6d5c4b3",
    timestamp: "2023-05-12T14:22:10",
    commodity: "Rice",
    quantity: "150 tons",
    broughtFrom: "Haryana Rice Producers",
    sourceLocation: "Karnal, Haryana",
    storedAt: "UP Regional Warehouse",
    storageLocation: "Lucknow, UP",
    soldTo: "UP Ration Center",
    destinationLocation: "Lucknow, UP",
    price: "₹32,500/ton",
    totalValue: "₹48,75,000",
    status: "Completed",
    previousHash: "0x6d5c4b3a291807e6d5c4b3a291807e6d5c4b3a2",
    blockNumber: 1045677,
    verified: true,
  },
  {
    id: "TX-003",
    hash: "0x6d5c4b3a29180796d5c4b3a29180796d5c4b3a2",
    timestamp: "2023-05-16T09:15:30",
    commodity: "Vegetables (Mixed)",
    quantity: "80 tons",
    broughtFrom: "Maharashtra Farms",
    sourceLocation: "Nashik, Maharashtra",
    storedAt: "Mumbai Distribution Center",
    storageLocation: "Mumbai, Maharashtra",
    soldTo: "Mumbai Ration Center",
    destinationLocation: "Mumbai, Maharashtra",
    price: "₹40,000/ton",
    totalValue: "₹32,00,000",
    status: "In Transit",
    previousHash: "0x5c4b3a29180796d5c4b3a29180796d5c4b3a291",
    blockNumber: 1045679,
    verified: true,
  },
  {
    id: "TX-004",
    hash: "0x5c4b3a2918079685c4b3a2918079685c4b3a291",
    timestamp: "2023-05-10T11:45:22",
    commodity: "Potatoes",
    quantity: "100 tons",
    broughtFrom: "Gujarat Farms",
    sourceLocation: "Ahmedabad, Gujarat",
    storedAt: "Gujarat Regional Warehouse",
    storageLocation: "Ahmedabad, Gujarat",
    soldTo: "Ahmedabad Ration Center",
    destinationLocation: "Ahmedabad, Gujarat",
    price: "₹25,000/ton",
    totalValue: "₹25,00,000",
    status: "Completed",
    previousHash: "0x4b3a2918079685c4b3a2918079685c4b3a2918",
    blockNumber: 1045675,
    verified: true,
  },
  {
    id: "TX-005",
    hash: "0x4b3a2918079685744b3a291807968574b3a2918",
    timestamp: "2023-05-14T16:30:15",
    commodity: "Onions",
    quantity: "50 tons",
    broughtFrom: "Maharashtra Farms",
    sourceLocation: "Nashik, Maharashtra",
    storedAt: "Pune Warehouse",
    storageLocation: "Pune, Maharashtra",
    soldTo: "Pune Ration Center",
    destinationLocation: "Pune, Maharashtra",
    price: "₹22,000/ton",
    totalValue: "₹11,00,000",
    status: "In Transit",
    previousHash: "0x3a2918079685743a2918079685743a29180796",
    blockNumber: 1045676,
    verified: true,
  },
  {
    id: "TX-006",
    hash: "0x3a29180796857433a29180796857433a29180796",
    timestamp: "2023-05-17T08:45:30",
    commodity: "Pulses (Mixed)",
    quantity: "30 tons",
    broughtFrom: "MP Pulse Growers",
    sourceLocation: "Indore, MP",
    storedAt: "Delhi South Warehouse",
    storageLocation: "South Delhi",
    soldTo: "South Delhi Distribution Center",
    destinationLocation: "South Delhi",
    price: "₹60,000/ton",
    totalValue: "₹18,00,000",
    status: "Processing",
    previousHash: "0x29180796857432918079685743291807968574",
    blockNumber: 1045680,
    verified: false,
  },
  {
    id: "TX-007",
    hash: "0x2918079685743291807968574329180796857432",
    timestamp: "2023-05-18T10:20:45",
    commodity: "Sugar",
    quantity: "40 tons",
    broughtFrom: "UP Sugar Mills Association",
    sourceLocation: "Meerut, UP",
    storedAt: "Delhi East Warehouse",
    storageLocation: "East Delhi",
    soldTo: "East Delhi Ration Center",
    destinationLocation: "East Delhi",
    price: "₹40,000/ton",
    totalValue: "₹16,00,000",
    status: "Processing",
    previousHash: "0x1807968574329180796857432918079685743",
    blockNumber: 1045681,
    verified: false,
  },
  {
    id: "TX-008",
    hash: "0x18079685743291807968574329180796857432918",
    timestamp: "2023-05-11T13:15:50",
    commodity: "Wheat",
    quantity: "120 tons",
    broughtFrom: "Haryana Wheat Growers",
    sourceLocation: "Karnal, Haryana",
    storedAt: "Delhi North Warehouse",
    storageLocation: "North Delhi",
    soldTo: "North Delhi Distribution Center",
    destinationLocation: "North Delhi",
    price: "₹31,500/ton",
    totalValue: "₹37,80,000",
    status: "Completed",
    previousHash: "0x0796857432918079685743291807968574329",
    blockNumber: 1045674,
    verified: true,
  },
  {
    id: "TX-009",
    hash: "0x0796857432918079685743291807968574329180",
    timestamp: "2023-05-19T09:30:15",
    commodity: "Rice",
    quantity: "100 tons",
    broughtFrom: "Punjab Rice Producers",
    sourceLocation: "Amritsar, Punjab",
    storedAt: "Haryana Central Warehouse",
    storageLocation: "Chandigarh, Haryana",
    soldTo: "Chandigarh Ration Center",
    destinationLocation: "Chandigarh",
    price: "₹32,000/ton",
    totalValue: "₹32,00,000",
    status: "Processing",
    previousHash: "0x9685743291807968574329180796857432918",
    blockNumber: 1045682,
    verified: false,
  },
  {
    id: "TX-010",
    hash: "0x9685743291807968574329180796857432918079",
    timestamp: "2023-05-13T15:40:25",
    commodity: "Vegetables (Mixed)",
    quantity: "40 tons",
    broughtFrom: "Pune Farmers Association",
    sourceLocation: "Pune, Maharashtra",
    storedAt: "Mumbai South Warehouse",
    storageLocation: "South Mumbai",
    soldTo: "South Mumbai Ration Center",
    destinationLocation: "South Mumbai",
    price: "₹41,000/ton",
    totalValue: "₹16,40,000",
    status: "Completed",
    previousHash: "0x8574329180796857432918079685743291807",
    blockNumber: 1045673,
    verified: true,
  },
]

export default function PublicLedgerPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [commodityFilter, setCommodityFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [expandedTransaction, setExpandedTransaction] = useState<string | null>(null)

  const handleLogout = async () => {
    try {
      await signOut(auth)
      router.push("/auth/login")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  const useCurrentUser = () => {
    const [user, setUser] = useState<any>(null)
    const auth = getAuth()

    useEffect(() => {
      const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
        if (firebaseUser) {
          setUser({
            uid: firebaseUser.uid,
            id: firebaseUser.uid,
            name: firebaseUser.displayName || null,
            email: firebaseUser.email || null,
            image: firebaseUser.photoURL || null,
          })
        } else {
          setUser(null)
        }
      })

      return () => unsubscribe()
    }, [auth])

    return user
  }

  const user = useCurrentUser()

  // Get unique commodities for filter
  const commodities = ["all", ...new Set(ledgerTransactions.map((tx) => tx.commodity))]

  // Filter transactions
  const filteredTransactions = ledgerTransactions.filter((tx) => {
    const matchesSearch =
      tx.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.hash.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.broughtFrom.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.storedAt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.soldTo.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCommodity = commodityFilter === "all" || tx.commodity === commodityFilter
    const matchesStatus = statusFilter === "all" || tx.status.toLowerCase() === statusFilter.toLowerCase()

    return matchesSearch && matchesCommodity && matchesStatus
  })

  const toggleTransaction = (id: string) => {
    if (expandedTransaction === id) {
      setExpandedTransaction(null)
    } else {
      setExpandedTransaction(id)
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-64 flex-col bg-gray-50 border-r md:flex">
        <div className="flex h-14 items-center border-b px-4">
          <Link href="/admin/dashboard" className="flex items-center gap-2 font-semibold">
            <Building className="h-5 w-5 text-purple-600" />
            <span>Admin Portal</span>
          </Link>
        </div>
        <nav className="flex-1 overflow-auto py-4">
          <div className="px-4 py-2">
            <h2 className="mb-2 text-xs font-semibold tracking-tight">Dashboard</h2>
            <div className="space-y-1">
              <Link href="/admin/dashboard">
                <Button variant="ghost" className="w-full justify-start">
                  <Home className="mr-2 h-4 w-4" />
                  Overview
                </Button>
              </Link>
              <Link href="/admin/tenders">
                <Button variant="ghost" className="w-full justify-start">
                  <FileText className="mr-2 h-4 w-4" />
                  Tenders
                </Button>
              </Link>
              <Link href="/admin/supply-chain">
                <Button variant="ghost" className="w-full justify-start">
                  <Truck className="mr-2 h-4 w-4" />
                  Supply Chain
                </Button>
              </Link>
              <Link href="/admin/ration-shops">
                <Button variant="ghost" className="w-full justify-start">
                  <Store className="mr-2 h-4 w-4" />
                  Ration Shops
                </Button>
              </Link>
              <Link href="/admin/public-ledger">
                <Button variant="secondary" className="w-full justify-start">
                  <Database className="mr-2 h-4 w-4" />
                  Public Ledger
                </Button>
              </Link>
            </div>
          </div>
        </nav>
        <div className="border-t p-4">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
              {user?.photoURL ? (
                <img src={user.photoURL || "/placeholder.svg"} alt="User" className="h-10 w-10 rounded-full" />
              ) : (
                <span className="text-sm font-semibold">{user?.displayName?.[0] || user?.email?.[0] || "U"}</span>
              )}
            </div>
            <div>
              <p className="text-sm font-medium">{user?.displayName || user?.email || "Unknown User"}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/consumer/settings">
              <Button variant="outline" size="sm" className="w-full">
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </Link>
            <Button variant="outline" size="sm" onClick={handleLogout} className="text-red-600 hover:bg-red-100">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        <div className="flex h-14 items-center border-b px-4 md:h-16">
          <Button variant="outline" size="sm" className="mr-4 md:hidden">
            <Building className="h-5 w-5 text-purple-600" />
          </Button>
        </div>

        <div className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">Public Ledger</h1>
              <p className="text-gray-500">Transparent and immutable record of all government transactions</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Button>
                <Database className="mr-2 h-4 w-4" />
                Export Ledger
              </Button>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div className="relative w-full md:w-auto md:flex-1 max-w-md">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search by ID, hash, source, or destination..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2 w-full md:w-auto">
              <Select value={commodityFilter} onValueChange={setCommodityFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Commodity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Commodities</SelectItem>
                  {commodities
                    .filter((c) => c !== "all")
                    .map((commodity) => (
                      <SelectItem key={commodity} value={commodity}>
                        {commodity}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="in transit">In Transit</SelectItem>
                  <SelectItem value="processing">Processing</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue="ledger" className="mb-6">
            <TabsList>
              <TabsTrigger value="ledger">Ledger View</TabsTrigger>
              <TabsTrigger value="blockchain">Blockchain View</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="ledger" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Transaction Ledger</CardTitle>
                  <CardDescription>Complete record of all commodity transactions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {filteredTransactions.map((tx) => (
                      <Collapsible
                        key={tx.id}
                        open={expandedTransaction === tx.id}
                        onOpenChange={() => toggleTransaction(tx.id)}
                        className="border rounded-md"
                      >
                        <div className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50">
                          <div className="flex items-center gap-4">
                            <div
                              className={`rounded-full p-2 ${
                                tx.status === "Completed"
                                  ? "bg-green-100"
                                  : tx.status === "In Transit"
                                    ? "bg-blue-100"
                                    : "bg-orange-100"
                              }`}
                            >
                              <ShieldCheck
                                className={`h-4 w-4 ${
                                  tx.status === "Completed"
                                    ? "text-green-600"
                                    : tx.status === "In Transit"
                                      ? "text-blue-600"
                                      : "text-orange-600"
                                }`}
                              />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-medium">{tx.id}</p>
                                <Badge
                                  className={
                                    tx.status === "Completed"
                                      ? "bg-green-100 text-green-800 hover:bg-green-100"
                                      : tx.status === "In Transit"
                                        ? "bg-blue-100 text-blue-800 hover:bg-blue-100"
                                        : "bg-orange-100 text-orange-800 hover:bg-orange-100"
                                  }
                                >
                                  {tx.status}
                                </Badge>
                                {tx.verified && (
                                  <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Verified</Badge>
                                )}
                              </div>
                              <p className="text-sm text-gray-500">
                                {tx.commodity} • {tx.quantity} • {new Date(tx.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <CollapsibleTrigger asChild>
                            <Button variant="ghost" size="sm">
                              {expandedTransaction === tx.id ? (
                                <ChevronUp className="h-4 w-4" />
                              ) : (
                                <ChevronDown className="h-4 w-4" />
                              )}
                            </Button>
                          </CollapsibleTrigger>
                        </div>
                        <CollapsibleContent>
                          <div className="border-t p-4 bg-gray-50">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div>
                                <h3 className="text-sm font-medium mb-2">Transaction Details</h3>
                                <div className="space-y-2">
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-500">Transaction Hash:</span>
                                    <span className="text-sm font-mono">{tx.hash.substring(0, 12)}...</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-500">Block Number:</span>
                                    <span className="text-sm">{tx.blockNumber}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-500">Timestamp:</span>
                                    <span className="text-sm">{new Date(tx.timestamp).toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-500">Total Value:</span>
                                    <span className="text-sm">{tx.totalValue}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-500">Price:</span>
                                    <span className="text-sm">{tx.price}</span>
                                  </div>
                                </div>
                              </div>
                              <div>
                                <h3 className="text-sm font-medium mb-2">Supply Chain Path</h3>
                                <div className="space-y-4">
                                  <div className="flex items-start gap-3">
                                    <div className="rounded-full bg-green-100 p-2 mt-1">
                                      <Truck className="h-4 w-4 text-green-600" />
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">Brought From</p>
                                      <p className="text-sm">{tx.broughtFrom}</p>
                                      <p className="text-xs text-gray-500">{tx.sourceLocation}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-start gap-3">
                                    <div className="rounded-full bg-blue-100 p-2 mt-1">
                                      <Database className="h-4 w-4 text-blue-600" />
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">Stored At</p>
                                      <p className="text-sm">{tx.storedAt}</p>
                                      <p className="text-xs text-gray-500">{tx.storageLocation}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-start gap-3">
                                    <div className="rounded-full bg-purple-100 p-2 mt-1">
                                      <Store className="h-4 w-4 text-purple-600" />
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">Sold To</p>
                                      <p className="text-sm">{tx.soldTo}</p>
                                      <p className="text-xs text-gray-500">{tx.destinationLocation}</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="mt-4 flex justify-end">
                              <Button variant="outline" size="sm" className="flex items-center gap-1">
                                <ExternalLink className="h-3 w-3" />
                                View on Explorer
                              </Button>
                            </div>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    ))}

                    {filteredTransactions.length === 0 && (
                      <div className="flex flex-col items-center justify-center py-12">
                        <Database className="h-16 w-16 text-gray-300 mb-4" />
                        <h2 className="text-xl font-semibold mb-2">No transactions found</h2>
                        <p className="text-gray-500 mb-6">Try adjusting your search or filters</p>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setSearchQuery("")
                            setCommodityFilter("all")
                            setStatusFilter("all")
                          }}
                        >
                          Reset Filters
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="blockchain" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Blockchain View</CardTitle>
                  <CardDescription>Visual representation of the transaction blockchain</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <div className="flex flex-nowrap gap-4 pb-4 min-w-max">
                      {ledgerTransactions
                        .sort((a, b) => b.blockNumber - a.blockNumber)
                        .slice(0, 6)
                        .map((tx, index) => (
                          <div
                            key={tx.id}
                            className="flex flex-col items-center min-w-[200px] max-w-[200px] border rounded-md p-4 bg-white"
                          >
                            <div className="text-xs font-mono bg-gray-100 px-2 py-1 rounded mb-2 w-full text-center">
                              Block #{tx.blockNumber}
                            </div>
                            <div className="text-xs font-mono text-gray-500 mb-2 truncate w-full text-center">
                              {tx.hash.substring(0, 10)}...
                            </div>
                            <div className="text-sm font-medium mb-1">{tx.commodity}</div>
                            <div className="text-xs text-gray-500 mb-2">{tx.quantity}</div>
                            <Badge
                              className={
                                tx.status === "Completed"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : tx.status === "In Transit"
                                    ? "bg-blue-100 text-blue-800 hover:bg-blue-100"
                                    : "bg-orange-100 text-orange-800 hover:bg-orange-100"
                              }
                            >
                              {tx.status}
                            </Badge>
                            <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
                              <Clock className="h-3 w-3" />
                              {new Date(tx.timestamp).toLocaleDateString()}
                            </div>
                            {index < 5 && (
                              <div className="absolute right-[-20px] top-1/2 transform -translate-y-1/2">
                                <div className="w-4 h-0.5 bg-gray-300"></div>
                              </div>
                            )}
                          </div>
                        ))}
                    </div>
                  </div>
                  <div className="mt-6 bg-gray-100 rounded-md p-4">
                    <h3 className="text-sm font-medium mb-2">Blockchain Statistics</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <div className="text-xs text-gray-500">Total Blocks</div>
                        <div className="text-xl font-semibold">1,045,682</div>
                      </div>
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <div className="text-xs text-gray-500">Total Transactions</div>
                        <div className="text-xl font-semibold">3,245,910</div>
                      </div>
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <div className="text-xs text-gray-500">Avg. Block Time</div>
                        <div className="text-xl font-semibold">15.2s</div>
                      </div>
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <div className="text-xs text-gray-500">Network Nodes</div>
                        <div className="text-xl font-semibold">24</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Ledger Analytics</CardTitle>
                  <CardDescription>Statistical analysis of transaction data</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px] bg-gray-100 rounded-md flex items-center justify-center">
                    <p className="text-gray-500">Analytics dashboard would be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
